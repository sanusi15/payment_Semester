<div class="sidebar">
    <div class="logo_content">
        <div class="logo">
            <i class='bx bxl-shopify'></i>
            <div class="logo_name">Poltek PGRI</div>
        </div>
        <i class='bx bx-menu' id="humber_menu"></i>
    </div>
    <div class="line"></div>
    <ul class="nav_list">
        <li>
            <a href="#">
                <i class='bx bx-grid-alt'></i>
                <span class="links_name">Dashboard</span>
            </a>
            <span class="tool">Dashboard</span>
        </li>
        <li>
            <a href="#">
                <i class='bx bx-user'></i>
                <span class="links_name">User</span>
            </a>
            <span class="tool">User</span>
        </li>
        <li>
            <a href="#">
                <i class='bx bx-history'></i>
                <span class="links_name">History</span>
            </a>
            <span class="tool">History</span>
        </li>
        <li>
            <a href="#">
                <i class='bx bx-credit-card'></i>
                <span class="links_name">Payment</span>
            </a>
            <span class="tool">Payment</span>
        </li>
        <li>
            <a href="#">
                <i class='bx bx-cog'></i>
                <span class="links_name">Settings</span>
            </a>
            <span class="tool">Settings</span>
        </li>
    </ul>
    <div class="profile_content">
        <div class="profile">
            <div class="profile_details">
                <img src="<?= base_url('asset/img/7.jpg'); ?>" alt="">
                <div class="name_job">
                    <div class="name"><?= $profile['nama']; ?></div>
                    <div class="job"><?= $profile['jurusan']; ?></div>
                </div>
            </div>
            <a href="logout">
                <i class='bx bx-log-in' id="logout"></i>
            </a>
        </div>
    </div>
</div>
<div class="home_content">
    


    
