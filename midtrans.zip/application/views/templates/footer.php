</div>
<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<!-- box ICON CDN -->
<script src="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css"></script>

<!-- sidebar -->
<script src="<?= base_url('asset/js/sidebar.js'); ?>"></script>



<!-- midtrans -->
<script type="text/javascript">    
    $('#pay-button').click(function(event) {
        // alert('ok')
        event.preventDefault();
        // $(this).attr("disabled", "disabled");
        
        var nim = $('#nim').html();
        var semester = $('#smstr').html();
        var jmlTagihan = $('.jml_tagihan').val();
        // konvert jadi int
        var convTagihan = parseInt(jmlTagihan);
        var jenisBayar = $('#jenisBayar').val();
        if(jenisBayar == 1){
            var jmlBayar = convTagihan / 2;
        }else{
            var jmlBayar = convTagihan;
        }
        

        $.ajax({
            url: '<?= site_url() ?>snap/token',
            data: {
                nim: nim,
                semester: semester,
                jmlBayar: jmlBayar,
            },
            method: 'POST',
            cache: false,
            success: function(data) {
                //location = data;

                console.log('token = ' + data);

                var resultType = document.getElementById('result-type');
                var resultData = document.getElementById('result-data');

                function changeResult(type, data) {
                    $("#result-type").val(type);
                    $("#result-data").val(JSON.stringify(data));
                    //resultType.innerHTML = type;
                    //resultData.innerHTML = JSON.stringify(data);
                }

                snap.pay(data, {

                    onSuccess: function(result) {
                        changeResult('success', result);
                        console.log(result.status_message);
                        console.log(result);
                        $("#payment-form").submit();
                    },
                    onPending: function(result) {
                        changeResult('pending', result);
                        console.log(result.status_message);
                        $("#payment-form").submit();
                    },
                    onError: function(result) {
                        changeResult('error', result);
                        console.log(result.status_message);
                        $("#payment-form").submit();
                    }
                });
            }
        });
    });    
</script>
</body>

</html>