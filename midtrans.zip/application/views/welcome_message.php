<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<!-- <script type="text/javascript" src="https://app.midtrans.com/snap/snap.js" data-client-key="Mid-client-bunQt9yGqx1tdhKw"></script> -->
	<script type="text/javascript" src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="SB-Mid-client-bzpYL188Mpzxr6fa"></script>

	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

	<title>Hello, world!</title>
</head>

<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<a class="navbar-brand" href="#">Pembayaran Semester</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		</div>
	</nav>

	<div class="container mt-5">
		<form id="payment-form" method="post" action="<?= site_url() ?>/snap/finish">
			<input type="hidden" name="result_type" id="result-type" value="">
			<input type="hidden" name="result_data" id="result-data" value="">
			<div class="form-group">
				<label for="nim">NIM</label>
				<input type="text" class="form-control" id="nim" name="nim">
				<div class="form-group">
					<div class="form-group">
						<label for="jurusan">Jurusan</label>
						<select name="jurusan" id="jurusan" class="form-control">
							<option value="MI">Manajenem Informatika</option>
							<option value="TE">Teknik Eleketronika</option>
							<option value="TM">Teknik Mesin</option>
						</select>
						<div class="form-group">
							<!-- <div class="form-group">
				<label for="jmlbayar">Jumlah Bayar</label>
				<input type="text" class="form-control" id="jmlbayar" >
			<div class="form-group"> -->
							<button id="pay-button" class="btn btn-primary mt-3">Bayar</button>
		</form>
		<div class="row mt-3">

			<table class="table">
				<thead>
					<tr>
						<th scope="col">No</th>
						<th scope="col">ID Bayaran</th>
						<th scope="col">Waktu</th>
						<th scope="col">Jenis Rekening</th>
						<th scope="col">Jumlah Bayaran</th>
						<th scope="col">Status</th>
						<th scope="col">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php $i = 1;
					foreach ($data as $b) : ?>
						<tr>
							<td scope="row"><?= $i++; ?></td>
							<td><?= $b['orderId']; ?></td>
							<td><?= $b['waktu']; ?></td>
							<td><?= $b['bank']; ?></td>
							<td>Rp. <?= number_format($b['jumlah_bayar'], 0, '.', '.'); ?></td>
							<td>
								<?php if ($b['status'] == 'pending') : ?>
									<p class=" badge badge-warning"><?= $b['status']; ?></p>
								<?php else : ?>
									<p class=" badge badge-success"><?= $b['status']; ?></p>
								<?php endif; ?>
							</td>
							<td>
								<a href="<?= $b['url']; ?>" download class="badge badge-primary">Download</a>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

		</div>
	</div>

	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

	<script type="text/javascript">
		$('#pay-button').click(function(event) {
			event.preventDefault();
			// $(this).attr("disabled", "disabled");

			var nim = $('#nim').val();
			var jurusan = $('#jurusan').val();

			$.ajax({
				url: '<?= site_url() ?>snap/token',
				// data: {
				// 	nim: nim,
				// 	jurusan: jurusan
				// },
				cache: false,

				success: function(data) {
					//location = data;

					console.log('token = ' + data);

					var resultType = document.getElementById('result-type');
					var resultData = document.getElementById('result-data');

					function changeResult(type, data) {
						$("#result-type").val(type);
						$("#result-data").val(JSON.stringify(data));
						//resultType.innerHTML = type;
						//resultData.innerHTML = JSON.stringify(data);
					}

					snap.pay(data, {

						onSuccess: function(result) {
							changeResult('success', result);
							console.log(result.status_message);
							console.log(result);
							$("#payment-form").submit();
						},
						onPending: function(result) {
							changeResult('pending', result);
							console.log(result.status_message);
							$("#payment-form").submit();
						},
						onError: function(result) {
							changeResult('error', result);
							console.log(result.status_message);
							$("#payment-form").submit();
						}
					});
				}
			});
		});
	</script>
</body>

</html>