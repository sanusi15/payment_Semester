<div class="container">
    <div class="card">
        <div class="row p-3">
            <div class="col-lg-3 col-md-12 col-sm-12">
                <table class="table table-bordered">
                    <tr>
                        <td>
                            <select class="form-select" aria-label="Default select example" id="semester">
                                <option selected disabled>Semester</option>
                                <option value="1">Satu</option>
                                <option value="2">Dua</option>
                                <option value="3">Tiga</option>
                                <option value="4">Empat</option>
                                <option value="5">Lima</option>
                                <option value="6">Enam</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-center">
                            <button class="btn btn-primary  w-50" onclick="lihatData()" style="font-size:13px;"><i class='bx bx-transfer-alt'></i> Proses</button>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="col-lg-9 col-md-12 col-sm-12 detailBayar">
                <form id="payment-form" method="post" action="<?= site_url() ?>snap/finish">
                    <input type="hidden" name="result_type" id="result-type" value="">
                    <input type="hidden" name="result_data" id="result-data" value="">
                    <div class="table-responsive">
                        <table class="table table-bordered" style="font-size: 14px;">
                            <tr class="text-center">
                                <td>Nama</td>
                                <td>NIM</td>
                                <td>Jurusan</td>
                                <td>Semester</td>
                                <td>Jumlah Tagihan</td>
                                <td>Cicilan 1</td>
                                <td>Cicilan 2</td>
                                <td>Total Bayar</td>
                                <td>Keterangan</td>
                                <td>Aksi</td>
                            </tr>
                            <tr>
                                <input type="hidden" value="" class="jml_tagihan" name="tagihan">
                                <input type="hidden" value="" class="semester" name="semester">
                                <td class="text-center" id="nama"></td>
                                <td class="text-center" id="nim"></td>
                                <td class="text-center" id="jurusan"></td>
                                <td class="text-center" id="smstr"></td>
                                <td id="jml_tagihan"></td>
                                <td id="cicilan1"></td>
                                <td id="cicilan2"></td>
                                <td id="total_bayar"></td>
                                <td class="text-center" id="keterangan"></td>
                                <td class="text-center" id="aksi"></td>
                            </tr>
                            <tr>
                                <td colspan="4">
                                    <select class="form-select" aria-label="Default select example" style="font-size:12px;" id="jenisBayar">
                                        <option selected disabled>Silahkan Pilih</option>
                                        <option value="2" id="bayarfull">Bayar Full</option>
                                        <option value="1">Bayar 1/2</option>
                                    </select>
                                </td>
                                <td colspan="5" class="text-center">
                                    <button id="pay-button" class="btn btn-primary  w-50" style="font-size:13px;">
                                        <i class='bx bxs-donate-heart'></i>
                                        Bayar
                                    </button>
                                </td>
                            </tr>
                        </table>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="row mt-3">
        <div class="col-12">
            <div class="alert alert-warning text-center peringatan" role="alert">
                Silahkan cek terlebih dahulu total biaya yang akan anda bayar, Jika tidak sesuai silahkan hubungi admin <br> Dan jangan lupa simpan (screenshoot) bukti pembayaran anda.
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-bordered" style="font-size: 14px;">
                    <tr class="text-center">
                        <td>No</td>
                        <td>Waktu</td>
                        <td>Bayar Semester</td>
                        <td>Order Id</td>
                        <td>Kode Pembayaran</td>
                        <td>Total Bayar</td>
                        <td>Jenis Pembayaran</td>
                        <td>Status</td>
                        <td>Aksi</td>
                    </tr>
                    <?php $i = 1;
                    foreach ($pending as $p) : ?>
                        <tr>
                            <td class="text-center"><?= $i++; ?></td>
                            <td class="text-center"><?= $p['waktu']; ?></td>
                            <td class="text-center"><?= $p['semester']; ?></td>
                            <td><?= $p['order_id']; ?></td>
                            <td><?= $p['kode_pembayaran']; ?></td>
                            <td>Rp. <?= $p['total_bayar']; ?></td>
                            <td class="text-center"><?= $p['method']; ?></td>
                            <td class="text-center">
                                <?php if($p['status'] == '201') : ?>
                                <span class="btn btn-warning w-100" style="font-size: 11px; margin:0; padding:4px;">Pending</span>
                                <?php elseif($p['status'] == '200') : ?>
                                <span class="btn btn-success w-100" style="font-size: 11px; margin:0; padding:4px;">Success</span>
                                <?php else : ?>
                                <span class="btn btn-danger w-100" style="font-size: 11px; margin:0; padding:4px;">Failed</span>
                                <?php endif; ?>
                        
                            </td>
                            <td class="text-center">
                                <a href="<?= $p['aksi']; ?>" style="font-size: 11px; margin:0; padding:4px;" class="btn btn-primary" target="_blank">Intruksi</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>
    </div>

    <!-- sweatAlert2 -->
    <script src="<?= base_url('asset/js/sweatAlert2.js'); ?>"></script>

    <script src="<?= base_url('asset/js/payment.js'); ?>"></script>